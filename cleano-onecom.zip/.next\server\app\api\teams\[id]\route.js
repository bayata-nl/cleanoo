(()=>{var e={};e.id=158,e.ids=[158],e.modules={846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},4870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},9294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},3033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},3873:e=>{"use strict";e.exports=require("path")},1429:(e,t,s)=>{"use strict";s.r(t),s.d(t,{patchFetch:()=>l,routeModule:()=>c,serverHooks:()=>u,workAsyncStorage:()=>p,workUnitAsyncStorage:()=>R});var a={};s.r(a),s.d(a,{DELETE:()=>N,GET:()=>o,PUT:()=>d});var r=s(2706),E=s(8203),T=s(5994),n=s(9187),i=s(513);async function o(e,{params:t}){try{let{id:e}=await t,s=`
      SELECT t.*, 
             p.name as team_leader_name,
             p.email as team_leader_email
      FROM teams t
      LEFT JOIN personnel p ON t.team_leader_id = p.id
      WHERE t.id = ?
    `,a=i.A.prepare(s).get(e);if(!a)return n.NextResponse.json({success:!1,error:"Team not found"},{status:404});let r=`
      SELECT tm.*, 
             p.name as personnel_name,
             p.email as personnel_email,
             p.role as personnel_role,
             p.specialization,
             p.experience_years
      FROM team_members tm
      JOIN personnel p ON tm.personnel_id = p.id
      WHERE tm.team_id = ?
      ORDER BY tm.role_in_team DESC, p.name ASC
    `,E=i.A.prepare(r).all(e);return n.NextResponse.json({success:!0,data:{...a,members:E}})}catch(e){return console.error("Database error:",e),n.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}async function d(e,{params:t}){try{let{id:s}=await t,a=await e.json();if(!i.A.prepare("SELECT id FROM teams WHERE id = ?").get(s))return n.NextResponse.json({success:!1,error:"Team not found"},{status:404});if(a.name&&i.A.prepare("SELECT id FROM teams WHERE name = ? AND id != ?").get(a.name,s))return n.NextResponse.json({success:!1,error:"Team name already exists"},{status:400});if(a.team_leader_id){let e=i.A.prepare("SELECT id, role FROM personnel WHERE id = ? AND status = ?").get(a.team_leader_id,"active");if(!e)return n.NextResponse.json({success:!1,error:"Team leader not found or inactive"},{status:400});if(!["supervisor","manager"].includes(e.role))return n.NextResponse.json({success:!1,error:"Only supervisors and managers can be team leaders"},{status:400})}let r=`
      UPDATE teams 
      SET name = COALESCE(?, name),
          description = COALESCE(?, description),
          team_leader_id = COALESCE(?, team_leader_id),
          status = COALESCE(?, status),
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `,E=[a.name?.trim()||null,a.description?.trim()||null,a.team_leader_id||null,a.status||null,s];i.A.prepare(r).run(E);let T=i.A.prepare("SELECT * FROM teams WHERE id = ?").get(s);return n.NextResponse.json({success:!0,data:T,message:"Team updated successfully"})}catch(e){return console.error("Database error:",e),n.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}async function N(e,{params:t}){try{let{id:e}=await t;if(!i.A.prepare("SELECT id FROM teams WHERE id = ?").get(e))return n.NextResponse.json({success:!1,error:"Team not found"},{status:404});if(i.A.prepare('SELECT COUNT(*) as count FROM assignments WHERE team_id = ? AND status IN ("assigned", "accepted", "in_progress")').get(e).count>0)return n.NextResponse.json({success:!1,error:"Cannot delete team with active assignments"},{status:400});return i.A.prepare("DELETE FROM teams WHERE id = ?").run(e),n.NextResponse.json({success:!0,message:"Team deleted successfully"})}catch(e){return console.error("Database error:",e),n.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}let c=new r.AppRouteRouteModule({definition:{kind:E.RouteKind.APP_ROUTE,page:"/api/teams/[id]/route",pathname:"/api/teams/[id]",filename:"route",bundlePath:"app/api/teams/[id]/route"},resolvedPagePath:"C:\\taylan\\web\\app\\api\\teams\\[id]\\route.ts",nextConfigOutput:"",userland:a}),{workAsyncStorage:p,workUnitAsyncStorage:R,serverHooks:u}=c;function l(){return(0,T.patchFetch)({workAsyncStorage:p,workUnitAsyncStorage:R})}},6487:()=>{},8335:()=>{},513:(e,t,s)=>{"use strict";let a;s.d(t,{A:()=>i});let r=require("better-sqlite3");var E=s.n(r),T=s(3873);let n=s.n(T)().join(process.cwd(),"database.sqlite");try{(a=new(E())(n)).pragma("journal_mode = WAL"),a.pragma("synchronous = NORMAL"),a.pragma("cache_size = 10000"),a.pragma("temp_store = memory")}catch(e){throw console.error("SQLite database connection error:",e),e}(function(){try{a.exec(`
      CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        service_type TEXT NOT NULL,
        preferred_date TEXT NOT NULL,
        preferred_time TEXT NOT NULL,
        notes TEXT,
        status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'assigned', 'in_progress', 'completed', 'cancelled')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        icon TEXT,
        price TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS testimonials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        text TEXT NOT NULL,
        rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS staff (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        phone TEXT NOT NULL,
        password TEXT DEFAULT 'welcome',
        role TEXT NOT NULL CHECK (role IN ('cleaner', 'supervisor', 'manager')),
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'on_leave')),
        specialization TEXT,
        experience_years INTEGER DEFAULT 0,
        hourly_rate DECIMAL(10,2),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        team_leader_id INTEGER,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_leader_id) REFERENCES staff(id)
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS team_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        staff_id INTEGER NOT NULL,
        role_in_team TEXT DEFAULT 'member' CHECK (role_in_team IN ('leader', 'member', 'specialist')),
        joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE,
        UNIQUE(team_id, staff_id)
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_id INTEGER NOT NULL,
        team_id INTEGER,
        staff_id INTEGER,
        assigned_by INTEGER NOT NULL,
        assignment_type TEXT NOT NULL CHECK (assignment_type IN ('team', 'individual')),
        status TEXT DEFAULT 'assigned' CHECK (status IN ('assigned', 'accepted', 'in_progress', 'completed', 'cancelled')),
        assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        accepted_at DATETIME,
        started_at DATETIME,
        completed_at DATETIME,
        notes TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE SET NULL,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE SET NULL,
        FOREIGN KEY (assigned_by) REFERENCES staff(id) ON DELETE SET NULL
      )
    `),console.log("✅ SQLite database successfully initialized"),console.log("\uD83D\uDCCA Database tables created successfully")}catch(e){throw console.error("❌ Database initialization error:",e),e}})(),process.on("SIGINT",()=>{a&&(a.close(),console.log("\uD83D\uDD12 SQLite database connection closed")),process.exit(0)});let i=a}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),a=t.X(0,[257,452],()=>s(1429));module.exports=a})();