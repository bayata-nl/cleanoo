(()=>{var e={};e.id=590,e.ids=[590],e.modules={846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},4870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},9294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},3033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},3873:e=>{"use strict";e.exports=require("path")},5106:(e,t,E)=>{"use strict";E.r(t),E.d(t,{patchFetch:()=>A,routeModule:()=>N,serverHooks:()=>p,workAsyncStorage:()=>c,workUnitAsyncStorage:()=>R});var s={};E.r(s),E.d(s,{DELETE:()=>d,PUT:()=>o});var T=E(2706),a=E(8203),r=E(5994),n=E(9187),i=E(513);async function o(e,{params:t}){try{let{id:E}=await t,s=await e.json(),T=i.A.prepare("SELECT * FROM assignments WHERE id = ?").get(E);if(!T)return n.NextResponse.json({success:!1,error:"Assignment not found"},{status:404});let a=`
      UPDATE assignments 
      SET status = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `,r=[s.status||T.status,s.notes||T.notes,E];if(i.A.prepare(a).run(r),s.status){let e="assigned";"completed"===s.status?e="completed":"cancelled"===s.status?e="cancelled":"in_progress"===s.status&&(e="in_progress"),i.A.prepare("UPDATE bookings SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = (SELECT booking_id FROM assignments WHERE id = ?)").run(e,E)}let o=i.A.prepare("SELECT * FROM assignments WHERE id = ?").get(E);return n.NextResponse.json({success:!0,data:o,message:"Assignment updated successfully"})}catch(e){return console.error("Database error:",e),n.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}async function d(e,{params:t}){try{let{id:e}=await t,E=i.A.prepare("SELECT * FROM assignments WHERE id = ?").get(e);if(!E)return n.NextResponse.json({success:!1,error:"Assignment not found"},{status:404});return i.A.prepare("UPDATE bookings SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").run("pending",E.booking_id),i.A.prepare("DELETE FROM assignments WHERE id = ?").run(e),n.NextResponse.json({success:!0,message:"Assignment deleted successfully"})}catch(e){return console.error("Database error:",e),n.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}let N=new T.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/assignments/[id]/route",pathname:"/api/assignments/[id]",filename:"route",bundlePath:"app/api/assignments/[id]/route"},resolvedPagePath:"C:\\taylan\\web\\app\\api\\assignments\\[id]\\route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:c,workUnitAsyncStorage:R,serverHooks:p}=N;function A(){return(0,r.patchFetch)({workAsyncStorage:c,workUnitAsyncStorage:R})}},6487:()=>{},8335:()=>{},513:(e,t,E)=>{"use strict";let s;E.d(t,{A:()=>i});let T=require("better-sqlite3");var a=E.n(T),r=E(3873);let n=E.n(r)().join(process.cwd(),"database.sqlite");try{(s=new(a())(n)).pragma("journal_mode = WAL"),s.pragma("synchronous = NORMAL"),s.pragma("cache_size = 10000"),s.pragma("temp_store = memory")}catch(e){throw console.error("SQLite database connection error:",e),e}(function(){try{s.exec(`
      CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        service_type TEXT NOT NULL,
        preferred_date TEXT NOT NULL,
        preferred_time TEXT NOT NULL,
        notes TEXT,
        status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'assigned', 'in_progress', 'completed', 'cancelled')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        icon TEXT,
        price TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS testimonials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        text TEXT NOT NULL,
        rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS staff (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        phone TEXT NOT NULL,
        password TEXT DEFAULT 'welcome',
        role TEXT NOT NULL CHECK (role IN ('cleaner', 'supervisor', 'manager')),
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'on_leave')),
        specialization TEXT,
        experience_years INTEGER DEFAULT 0,
        hourly_rate DECIMAL(10,2),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        team_leader_id INTEGER,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_leader_id) REFERENCES staff(id)
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS team_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        staff_id INTEGER NOT NULL,
        role_in_team TEXT DEFAULT 'member' CHECK (role_in_team IN ('leader', 'member', 'specialist')),
        joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE,
        UNIQUE(team_id, staff_id)
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_id INTEGER NOT NULL,
        team_id INTEGER,
        staff_id INTEGER,
        assigned_by INTEGER NOT NULL,
        assignment_type TEXT NOT NULL CHECK (assignment_type IN ('team', 'individual')),
        status TEXT DEFAULT 'assigned' CHECK (status IN ('assigned', 'accepted', 'in_progress', 'completed', 'cancelled')),
        assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        accepted_at DATETIME,
        started_at DATETIME,
        completed_at DATETIME,
        notes TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE SET NULL,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE SET NULL,
        FOREIGN KEY (assigned_by) REFERENCES staff(id) ON DELETE SET NULL
      )
    `),console.log("✅ SQLite database successfully initialized"),console.log("\uD83D\uDCCA Database tables created successfully")}catch(e){throw console.error("❌ Database initialization error:",e),e}})(),process.on("SIGINT",()=>{s&&(s.close(),console.log("\uD83D\uDD12 SQLite database connection closed")),process.exit(0)});let i=s}};var t=require("../../../../webpack-runtime.js");t.C(e);var E=e=>t(t.s=e),s=t.X(0,[257,452],()=>E(5106));module.exports=s})();