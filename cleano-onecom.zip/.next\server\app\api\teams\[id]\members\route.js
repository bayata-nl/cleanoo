(()=>{var e={};e.id=638,e.ids=[638],e.modules={846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},4870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},9294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},3033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},3873:e=>{"use strict";e.exports=require("path")},4407:(e,t,s)=>{"use strict";s.r(t),s.d(t,{patchFetch:()=>u,routeModule:()=>N,serverHooks:()=>R,workAsyncStorage:()=>c,workUnitAsyncStorage:()=>m});var a={};s.r(a),s.d(a,{GET:()=>o,POST:()=>d});var E=s(2706),r=s(8203),T=s(5994),i=s(9187),n=s(513);async function o(e,{params:t}){try{let{id:e}=await t;if(!n.A.prepare("SELECT id FROM teams WHERE id = ?").get(e))return i.NextResponse.json({success:!1,error:"Team not found"},{status:404});let s=`
      SELECT tm.*, 
             s.name as staff_name,
             s.email as staff_email,
             s.role as staff_role,
             s.specialization,
             s.experience_years,
             s.status as staff_status
      FROM team_members tm
      JOIN staff s ON tm.staff_id = s.id
      WHERE tm.team_id = ?
      ORDER BY tm.role_in_team DESC, s.name ASC
    `,a=n.A.prepare(s).all(e);return i.NextResponse.json({success:!0,data:a})}catch(e){return console.error("Database error:",e),i.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}async function d(e,{params:t}){try{let{id:s}=await t,a=await e.json();if(!n.A.prepare("SELECT id FROM teams WHERE id = ?").get(s))return i.NextResponse.json({success:!1,error:"Team not found"},{status:404});if(!a.staff_id||!a.role_in_team)return i.NextResponse.json({success:!1,error:"Missing required fields: staff_id, role_in_team"},{status:400});let E=n.A.prepare("SELECT id, status FROM staff WHERE id = ?").get(a.staff_id);if(!E)return i.NextResponse.json({success:!1,error:"Staff not found"},{status:404});if("active"!==E.status)return i.NextResponse.json({success:!1,error:"Staff is not active"},{status:400});if(n.A.prepare("SELECT id FROM team_members WHERE team_id = ? AND staff_id = ?").get(s,a.staff_id))return i.NextResponse.json({success:!1,error:"Staff is already a member of this team"},{status:400});if(n.A.prepare("SELECT team_id FROM team_members WHERE staff_id = ?").get(a.staff_id))return i.NextResponse.json({success:!1,error:"Staff is already a member of another team"},{status:400});let r=`
      INSERT INTO team_members (team_id, staff_id, role_in_team)
      VALUES (?, ?, ?)
    `,T=[s,a.staff_id,a.role_in_team],o=n.A.prepare(r).run(T),d=n.A.prepare(`
      SELECT tm.*, 
             s.name as staff_name,
             s.email as staff_email,
             s.role as staff_role
      FROM team_members tm
      JOIN staff s ON tm.staff_id = s.id
      WHERE tm.id = ?
    `).get(o.lastInsertRowid);return i.NextResponse.json({success:!0,data:d,message:"Team member added successfully"},{status:201})}catch(e){return console.error("Database error:",e),i.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}let N=new E.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/teams/[id]/members/route",pathname:"/api/teams/[id]/members",filename:"route",bundlePath:"app/api/teams/[id]/members/route"},resolvedPagePath:"C:\\taylan\\web\\app\\api\\teams\\[id]\\members\\route.ts",nextConfigOutput:"",userland:a}),{workAsyncStorage:c,workUnitAsyncStorage:m,serverHooks:R}=N;function u(){return(0,T.patchFetch)({workAsyncStorage:c,workUnitAsyncStorage:m})}},6487:()=>{},8335:()=>{},513:(e,t,s)=>{"use strict";let a;s.d(t,{A:()=>n});let E=require("better-sqlite3");var r=s.n(E),T=s(3873);let i=s.n(T)().join(process.cwd(),"database.sqlite");try{(a=new(r())(i)).pragma("journal_mode = WAL"),a.pragma("synchronous = NORMAL"),a.pragma("cache_size = 10000"),a.pragma("temp_store = memory")}catch(e){throw console.error("SQLite database connection error:",e),e}(function(){try{a.exec(`
      CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        service_type TEXT NOT NULL,
        preferred_date TEXT NOT NULL,
        preferred_time TEXT NOT NULL,
        notes TEXT,
        status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'assigned', 'in_progress', 'completed', 'cancelled')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        icon TEXT,
        price TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS testimonials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        text TEXT NOT NULL,
        rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS staff (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        phone TEXT NOT NULL,
        password TEXT DEFAULT 'welcome',
        role TEXT NOT NULL CHECK (role IN ('cleaner', 'supervisor', 'manager')),
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'on_leave')),
        specialization TEXT,
        experience_years INTEGER DEFAULT 0,
        hourly_rate DECIMAL(10,2),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        team_leader_id INTEGER,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_leader_id) REFERENCES staff(id)
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS team_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        staff_id INTEGER NOT NULL,
        role_in_team TEXT DEFAULT 'member' CHECK (role_in_team IN ('leader', 'member', 'specialist')),
        joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE,
        UNIQUE(team_id, staff_id)
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_id INTEGER NOT NULL,
        team_id INTEGER,
        staff_id INTEGER,
        assigned_by INTEGER NOT NULL,
        assignment_type TEXT NOT NULL CHECK (assignment_type IN ('team', 'individual')),
        status TEXT DEFAULT 'assigned' CHECK (status IN ('assigned', 'accepted', 'in_progress', 'completed', 'cancelled')),
        assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        accepted_at DATETIME,
        started_at DATETIME,
        completed_at DATETIME,
        notes TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE SET NULL,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE SET NULL,
        FOREIGN KEY (assigned_by) REFERENCES staff(id) ON DELETE SET NULL
      )
    `),console.log("✅ SQLite database successfully initialized"),console.log("\uD83D\uDCCA Database tables created successfully")}catch(e){throw console.error("❌ Database initialization error:",e),e}})(),process.on("SIGINT",()=>{a&&(a.close(),console.log("\uD83D\uDD12 SQLite database connection closed")),process.exit(0)});let n=a}};var t=require("../../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),a=t.X(0,[257,452],()=>s(4407));module.exports=a})();