(()=>{var e={};e.id=438,e.ids=[438],e.modules={846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},4870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},9294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},3033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},3873:e=>{"use strict";e.exports=require("path")},6523:(e,E,t)=>{"use strict";t.r(E),t.d(E,{patchFetch:()=>A,routeModule:()=>c,serverHooks:()=>I,workAsyncStorage:()=>d,workUnitAsyncStorage:()=>R});var T={};t.r(T),t.d(T,{GET:()=>o,POST:()=>N});var s=t(2706),r=t(8203),a=t(5994),i=t(9187),n=t(513);async function o(){try{let e=n.A.prepare("SELECT * FROM services ORDER BY created_at DESC").all();return i.NextResponse.json({success:!0,data:e})}catch(e){return console.error("Database error:",e),i.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}async function N(e){try{let{title:E,description:t,icon:T,price:s}=await e.json();if(!E||!t)return i.NextResponse.json({error:"Title and description are required"},{status:400});let r=n.A.prepare(`
      INSERT INTO services (title, description, icon, price) 
      VALUES (?, ?, ?, ?)
    `).run(E,t,T||"",s||""),a=n.A.prepare("SELECT * FROM services WHERE id = ?").get(r.lastInsertRowid);return i.NextResponse.json({success:!0,data:a,message:"Service successfully created"},{status:201})}catch(e){return console.error("Database error:",e),i.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}let c=new s.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/services/route",pathname:"/api/services",filename:"route",bundlePath:"app/api/services/route"},resolvedPagePath:"C:\\taylan\\web\\app\\api\\services\\route.ts",nextConfigOutput:"",userland:T}),{workAsyncStorage:d,workUnitAsyncStorage:R,serverHooks:I}=c;function A(){return(0,a.patchFetch)({workAsyncStorage:d,workUnitAsyncStorage:R})}},6487:()=>{},8335:()=>{},513:(e,E,t)=>{"use strict";let T;t.d(E,{A:()=>n});let s=require("better-sqlite3");var r=t.n(s),a=t(3873);let i=t.n(a)().join(process.cwd(),"database.sqlite");try{(T=new(r())(i)).pragma("journal_mode = WAL"),T.pragma("synchronous = NORMAL"),T.pragma("cache_size = 10000"),T.pragma("temp_store = memory")}catch(e){throw console.error("SQLite database connection error:",e),e}(function(){try{T.exec(`
      CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        service_type TEXT NOT NULL,
        preferred_date TEXT NOT NULL,
        preferred_time TEXT NOT NULL,
        notes TEXT,
        status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'assigned', 'in_progress', 'completed', 'cancelled')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),T.exec(`
      CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        icon TEXT,
        price TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),T.exec(`
      CREATE TABLE IF NOT EXISTS testimonials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        text TEXT NOT NULL,
        rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),T.exec(`
      CREATE TABLE IF NOT EXISTS staff (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        phone TEXT NOT NULL,
        password TEXT DEFAULT 'welcome',
        role TEXT NOT NULL CHECK (role IN ('cleaner', 'supervisor', 'manager')),
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'on_leave')),
        specialization TEXT,
        experience_years INTEGER DEFAULT 0,
        hourly_rate DECIMAL(10,2),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),T.exec(`
      CREATE TABLE IF NOT EXISTS teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        team_leader_id INTEGER,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_leader_id) REFERENCES staff(id)
      )
    `),T.exec(`
      CREATE TABLE IF NOT EXISTS team_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        staff_id INTEGER NOT NULL,
        role_in_team TEXT DEFAULT 'member' CHECK (role_in_team IN ('leader', 'member', 'specialist')),
        joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE,
        UNIQUE(team_id, staff_id)
      )
    `),T.exec(`
      CREATE TABLE IF NOT EXISTS assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_id INTEGER NOT NULL,
        team_id INTEGER,
        staff_id INTEGER,
        assigned_by INTEGER NOT NULL,
        assignment_type TEXT NOT NULL CHECK (assignment_type IN ('team', 'individual')),
        status TEXT DEFAULT 'assigned' CHECK (status IN ('assigned', 'accepted', 'in_progress', 'completed', 'cancelled')),
        assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        accepted_at DATETIME,
        started_at DATETIME,
        completed_at DATETIME,
        notes TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE SET NULL,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE SET NULL,
        FOREIGN KEY (assigned_by) REFERENCES staff(id) ON DELETE SET NULL
      )
    `),console.log("✅ SQLite database successfully initialized"),console.log("\uD83D\uDCCA Database tables created successfully")}catch(e){throw console.error("❌ Database initialization error:",e),e}})(),process.on("SIGINT",()=>{T&&(T.close(),console.log("\uD83D\uDD12 SQLite database connection closed")),process.exit(0)});let n=T}};var E=require("../../../webpack-runtime.js");E.C(e);var t=e=>E(E.s=e),T=E.X(0,[257,452],()=>t(6523));module.exports=T})();