/** @type {import('next').NextConfig} */
const nextConfig = {
  // Basic Next.js configuration
}

module.exports = nextConfig 