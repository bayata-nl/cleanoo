(()=>{var e={};e.id=612,e.ids=[612],e.modules={846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},4870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},9294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},3033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},3873:e=>{"use strict";e.exports=require("path")},1552:(e,t,E)=>{"use strict";E.r(t),E.d(t,{patchFetch:()=>l,routeModule:()=>c,serverHooks:()=>p,workAsyncStorage:()=>d,workUnitAsyncStorage:()=>R});var s={};E.r(s),E.d(s,{GET:()=>o,POST:()=>N});var a=E(2706),T=E(8203),r=E(5994),i=E(9187),n=E(513);async function o(e){try{let{searchParams:t}=new URL(e.url),E=t.get("role"),s=t.get("status"),a="SELECT * FROM staff WHERE 1=1",T=[];E&&(a+=" AND role = ?",T.push(E)),s&&(a+=" AND status = ?",T.push(s)),a+=" ORDER BY created_at DESC";let r=n.A.prepare(a).all(...T);return i.NextResponse.json({success:!0,data:r})}catch(e){return console.error("Staff fetch error:",e),i.NextResponse.json({success:!1,error:"Failed to fetch staff"},{status:500})}}async function N(e){try{let{name:t,email:E,phone:s,password:a,role:T,status:r,specialization:o,experience_years:N,hourly_rate:c}=await e.json();if(!t||!E||!s||!T)return i.NextResponse.json({success:!1,error:"Name, email, phone, and role are required"},{status:400});if(n.A.prepare("SELECT id FROM staff WHERE email = ?").get(E))return i.NextResponse.json({success:!1,error:"Email already exists"},{status:400});let d=n.A.prepare(`
      INSERT INTO staff (name, email, phone, password, role, status, specialization, experience_years, hourly_rate)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(t,E,s,a||"welcome",T,r||"active",o||null,N||0,c||null),R=n.A.prepare("SELECT * FROM staff WHERE id = ?").get(d.lastInsertRowid);return i.NextResponse.json({success:!0,data:R,message:"Staff member created successfully"})}catch(e){return console.error("Staff creation error:",e),i.NextResponse.json({success:!1,error:"Failed to create staff member"},{status:500})}}let c=new a.AppRouteRouteModule({definition:{kind:T.RouteKind.APP_ROUTE,page:"/api/staff/route",pathname:"/api/staff",filename:"route",bundlePath:"app/api/staff/route"},resolvedPagePath:"C:\\taylan\\web\\app\\api\\staff\\route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:d,workUnitAsyncStorage:R,serverHooks:p}=c;function l(){return(0,r.patchFetch)({workAsyncStorage:d,workUnitAsyncStorage:R})}},6487:()=>{},8335:()=>{},513:(e,t,E)=>{"use strict";let s;E.d(t,{A:()=>n});let a=require("better-sqlite3");var T=E.n(a),r=E(3873);let i=E.n(r)().join(process.cwd(),"database.sqlite");try{(s=new(T())(i)).pragma("journal_mode = WAL"),s.pragma("synchronous = NORMAL"),s.pragma("cache_size = 10000"),s.pragma("temp_store = memory")}catch(e){throw console.error("SQLite database connection error:",e),e}(function(){try{s.exec(`
      CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        service_type TEXT NOT NULL,
        preferred_date TEXT NOT NULL,
        preferred_time TEXT NOT NULL,
        notes TEXT,
        status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'assigned', 'in_progress', 'completed', 'cancelled')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        icon TEXT,
        price TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS testimonials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        text TEXT NOT NULL,
        rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS staff (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        phone TEXT NOT NULL,
        password TEXT DEFAULT 'welcome',
        role TEXT NOT NULL CHECK (role IN ('cleaner', 'supervisor', 'manager')),
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'on_leave')),
        specialization TEXT,
        experience_years INTEGER DEFAULT 0,
        hourly_rate DECIMAL(10,2),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        team_leader_id INTEGER,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_leader_id) REFERENCES staff(id)
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS team_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        staff_id INTEGER NOT NULL,
        role_in_team TEXT DEFAULT 'member' CHECK (role_in_team IN ('leader', 'member', 'specialist')),
        joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE,
        UNIQUE(team_id, staff_id)
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_id INTEGER NOT NULL,
        team_id INTEGER,
        staff_id INTEGER,
        assigned_by INTEGER NOT NULL,
        assignment_type TEXT NOT NULL CHECK (assignment_type IN ('team', 'individual')),
        status TEXT DEFAULT 'assigned' CHECK (status IN ('assigned', 'accepted', 'in_progress', 'completed', 'cancelled')),
        assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        accepted_at DATETIME,
        started_at DATETIME,
        completed_at DATETIME,
        notes TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE SET NULL,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE SET NULL,
        FOREIGN KEY (assigned_by) REFERENCES staff(id) ON DELETE SET NULL
      )
    `),console.log("✅ SQLite database successfully initialized"),console.log("\uD83D\uDCCA Database tables created successfully")}catch(e){throw console.error("❌ Database initialization error:",e),e}})(),process.on("SIGINT",()=>{s&&(s.close(),console.log("\uD83D\uDD12 SQLite database connection closed")),process.exit(0)});let n=s}};var t=require("../../../webpack-runtime.js");t.C(e);var E=e=>t(t.s=e),s=t.X(0,[257,452],()=>E(1552));module.exports=s})();