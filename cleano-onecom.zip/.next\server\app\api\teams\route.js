(()=>{var e={};e.id=52,e.ids=[52],e.modules={846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},4870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},9294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},3033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},3873:e=>{"use strict";e.exports=require("path")},8359:(e,t,a)=>{"use strict";a.r(t),a.d(t,{patchFetch:()=>R,routeModule:()=>N,serverHooks:()=>m,workAsyncStorage:()=>c,workUnitAsyncStorage:()=>l});var s={};a.r(s),a.d(s,{GET:()=>o,POST:()=>d});var E=a(2706),r=a(8203),T=a(5994),i=a(9187),n=a(513);async function o(e){try{let{searchParams:t}=new URL(e.url),a=t.get("status"),s=`
      SELECT t.*, 
             s.name as team_leader_name,
             s.email as team_leader_email
      FROM teams t
      LEFT JOIN staff s ON t.team_leader_id = s.id
      WHERE 1=1
    `,E=[];a&&(s+=" AND t.status = ?",E.push(a)),s+=" ORDER BY t.created_at DESC";let r=n.A.prepare(s).all(E),T=`
      SELECT tm.*, 
             s.name as staff_name,
             s.email as staff_email,
             s.role as staff_role,
             s.specialization as staff_specialization
      FROM team_members tm
      LEFT JOIN staff s ON tm.staff_id = s.id
      WHERE tm.team_id = ?
      ORDER BY tm.role_in_team DESC, s.name ASC
    `,o=n.A.prepare(T),d=r.map(e=>{let t=o.all(e.id);return{...e,members:t.map(e=>({id:e.id,team_id:e.team_id,staff_id:e.staff_id,role_in_team:e.role_in_team,joined_at:e.joined_at,staff:{name:e.staff_name,email:e.staff_email,role:e.staff_role,specialization:e.staff_specialization}})),member_count:t.length}});return i.NextResponse.json({success:!0,data:d})}catch(e){return console.error("Database error:",e),i.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}async function d(e){try{let t=await e.json();if(!t.name)return i.NextResponse.json({success:!1,error:"Missing required field: name"},{status:400});if(n.A.prepare("SELECT id FROM teams WHERE name = ?").get(t.name))return i.NextResponse.json({success:!1,error:"Team name already exists"},{status:400});if(t.team_leader_id){let e=n.A.prepare("SELECT id, role FROM staff WHERE id = ? AND status = ?").get(t.team_leader_id,"active");if(!e)return i.NextResponse.json({success:!1,error:"Team leader not found or inactive"},{status:400});if(!["supervisor","manager"].includes(e.role))return i.NextResponse.json({success:!1,error:"Team leader must be a supervisor or manager"},{status:400})}let a=`
      INSERT INTO teams (name, description, team_leader_id, status)
      VALUES (?, ?, ?, ?)
    `,s=[t.name.trim(),t.description?.trim()||null,t.team_leader_id||null,t.status||"active"],E=n.A.prepare(a).run(s),r=n.A.prepare("SELECT * FROM teams WHERE id = ?").get(E.lastInsertRowid);return i.NextResponse.json({success:!0,data:r,message:"Team created successfully"},{status:201})}catch(e){return console.error("Database error:",e),i.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}let N=new E.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/teams/route",pathname:"/api/teams",filename:"route",bundlePath:"app/api/teams/route"},resolvedPagePath:"C:\\taylan\\web\\app\\api\\teams\\route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:c,workUnitAsyncStorage:l,serverHooks:m}=N;function R(){return(0,T.patchFetch)({workAsyncStorage:c,workUnitAsyncStorage:l})}},6487:()=>{},8335:()=>{},513:(e,t,a)=>{"use strict";let s;a.d(t,{A:()=>n});let E=require("better-sqlite3");var r=a.n(E),T=a(3873);let i=a.n(T)().join(process.cwd(),"database.sqlite");try{(s=new(r())(i)).pragma("journal_mode = WAL"),s.pragma("synchronous = NORMAL"),s.pragma("cache_size = 10000"),s.pragma("temp_store = memory")}catch(e){throw console.error("SQLite database connection error:",e),e}(function(){try{s.exec(`
      CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        service_type TEXT NOT NULL,
        preferred_date TEXT NOT NULL,
        preferred_time TEXT NOT NULL,
        notes TEXT,
        status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'assigned', 'in_progress', 'completed', 'cancelled')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        icon TEXT,
        price TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS testimonials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        text TEXT NOT NULL,
        rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS staff (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        phone TEXT NOT NULL,
        password TEXT DEFAULT 'welcome',
        role TEXT NOT NULL CHECK (role IN ('cleaner', 'supervisor', 'manager')),
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'on_leave')),
        specialization TEXT,
        experience_years INTEGER DEFAULT 0,
        hourly_rate DECIMAL(10,2),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        team_leader_id INTEGER,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_leader_id) REFERENCES staff(id)
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS team_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        staff_id INTEGER NOT NULL,
        role_in_team TEXT DEFAULT 'member' CHECK (role_in_team IN ('leader', 'member', 'specialist')),
        joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE,
        UNIQUE(team_id, staff_id)
      )
    `),s.exec(`
      CREATE TABLE IF NOT EXISTS assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_id INTEGER NOT NULL,
        team_id INTEGER,
        staff_id INTEGER,
        assigned_by INTEGER NOT NULL,
        assignment_type TEXT NOT NULL CHECK (assignment_type IN ('team', 'individual')),
        status TEXT DEFAULT 'assigned' CHECK (status IN ('assigned', 'accepted', 'in_progress', 'completed', 'cancelled')),
        assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        accepted_at DATETIME,
        started_at DATETIME,
        completed_at DATETIME,
        notes TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE SET NULL,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE SET NULL,
        FOREIGN KEY (assigned_by) REFERENCES staff(id) ON DELETE SET NULL
      )
    `),console.log("✅ SQLite database successfully initialized"),console.log("\uD83D\uDCCA Database tables created successfully")}catch(e){throw console.error("❌ Database initialization error:",e),e}})(),process.on("SIGINT",()=>{s&&(s.close(),console.log("\uD83D\uDD12 SQLite database connection closed")),process.exit(0)});let n=s}};var t=require("../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),s=t.X(0,[257,452],()=>a(8359));module.exports=s})();