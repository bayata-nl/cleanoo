(()=>{var e={};e.id=692,e.ids=[692],e.modules={846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},4870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},9294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},3033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},3873:e=>{"use strict";e.exports=require("path")},96:(e,s,t)=>{"use strict";t.r(s),t.d(s,{patchFetch:()=>p,routeModule:()=>N,serverHooks:()=>R,workAsyncStorage:()=>c,workUnitAsyncStorage:()=>u});var a={};t.r(a),t.d(a,{GET:()=>o,POST:()=>d});var E=t(2706),r=t(8203),i=t(5994),n=t(9187),T=t(513);async function o(e){try{let{searchParams:s}=new URL(e.url),t=s.get("staff_id"),a=s.get("team_id"),E=s.get("status"),r=s.get("booking_id"),i=`
      SELECT a.*,
             b.name as customer_name,
             b.email as customer_email,
             b.phone as customer_phone,
             b.address as customer_address,
             b.service_type,
             b.preferred_date,
             b.preferred_time,
             b.notes as booking_notes,
             s.name as staff_name,
             s.email as staff_email,
             t.name as team_name,
             ab.name as assigned_by_name
      FROM assignments a
      JOIN bookings b ON a.booking_id = b.id
      LEFT JOIN staff s ON a.staff_id = s.id
      LEFT JOIN teams t ON a.team_id = t.id
      LEFT JOIN staff ab ON a.assigned_by = ab.id
      WHERE 1=1
    `,o=[];t&&(i+=" AND a.staff_id = ?",o.push(t)),a&&(i+=" AND a.team_id = ?",o.push(a)),E&&(i+=" AND a.status = ?",o.push(E)),r&&(i+=" AND a.booking_id = ?",o.push(r)),i+=" ORDER BY a.assigned_at DESC";let d=T.A.prepare(i).all(o);return n.NextResponse.json({success:!0,data:d})}catch(e){return console.error("Database error:",e),n.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}async function d(e){try{let s=await e.json();if(!s.booking_id||!s.assignment_type)return n.NextResponse.json({success:!1,error:"Missing required fields: booking_id, assignment_type"},{status:400});if(!T.A.prepare("SELECT id, status FROM bookings WHERE id = ?").get(s.booking_id))return n.NextResponse.json({success:!1,error:"Booking not found"},{status:404});if(T.A.prepare("SELECT id FROM assignments WHERE booking_id = ?").get(s.booking_id))return n.NextResponse.json({success:!1,error:"Booking already has an assignment"},{status:400});if("team"===s.assignment_type){if(!s.team_id)return n.NextResponse.json({success:!1,error:"team_id is required for team assignments"},{status:400});let e=T.A.prepare("SELECT id, status FROM teams WHERE id = ?").get(s.team_id);if(!e)return n.NextResponse.json({success:!1,error:"Team not found"},{status:404});if("active"!==e.status)return n.NextResponse.json({success:!1,error:"Team is not active"},{status:400})}else if("individual"===s.assignment_type){if(!s.staff_id)return n.NextResponse.json({success:!1,error:"staff_id is required for individual assignments"},{status:400});let e=T.A.prepare("SELECT id, status FROM staff WHERE id = ?").get(s.staff_id);if(!e)return n.NextResponse.json({success:!1,error:"Staff not found"},{status:404});if("active"!==e.status)return n.NextResponse.json({success:!1,error:"Staff is not active"},{status:400})}let t=s.assigned_by||1,a=`
      INSERT INTO assignments (booking_id, team_id, staff_id, assigned_by, assignment_type, status, notes)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `,E=[s.booking_id,s.team_id||null,s.staff_id||null,t,s.assignment_type,(s.status||"assigned").toLowerCase(),s.notes?.trim()||null],r=T.A.prepare(a).run(E);T.A.prepare("UPDATE bookings SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").run("assigned",s.booking_id);let i=T.A.prepare("SELECT * FROM assignments WHERE id = ?").get(r.lastInsertRowid);return n.NextResponse.json({success:!0,data:i,message:"Assignment created successfully"},{status:201})}catch(e){return console.error("Database error:",e),n.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}let N=new E.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/assignments/route",pathname:"/api/assignments",filename:"route",bundlePath:"app/api/assignments/route"},resolvedPagePath:"C:\\taylan\\web\\app\\api\\assignments\\route.ts",nextConfigOutput:"",userland:a}),{workAsyncStorage:c,workUnitAsyncStorage:u,serverHooks:R}=N;function p(){return(0,i.patchFetch)({workAsyncStorage:c,workUnitAsyncStorage:u})}},6487:()=>{},8335:()=>{},513:(e,s,t)=>{"use strict";let a;t.d(s,{A:()=>T});let E=require("better-sqlite3");var r=t.n(E),i=t(3873);let n=t.n(i)().join(process.cwd(),"database.sqlite");try{(a=new(r())(n)).pragma("journal_mode = WAL"),a.pragma("synchronous = NORMAL"),a.pragma("cache_size = 10000"),a.pragma("temp_store = memory")}catch(e){throw console.error("SQLite database connection error:",e),e}(function(){try{a.exec(`
      CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        service_type TEXT NOT NULL,
        preferred_date TEXT NOT NULL,
        preferred_time TEXT NOT NULL,
        notes TEXT,
        status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'assigned', 'in_progress', 'completed', 'cancelled')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        icon TEXT,
        price TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS testimonials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        text TEXT NOT NULL,
        rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS staff (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        phone TEXT NOT NULL,
        password TEXT DEFAULT 'welcome',
        role TEXT NOT NULL CHECK (role IN ('cleaner', 'supervisor', 'manager')),
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'on_leave')),
        specialization TEXT,
        experience_years INTEGER DEFAULT 0,
        hourly_rate DECIMAL(10,2),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        team_leader_id INTEGER,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_leader_id) REFERENCES staff(id)
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS team_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        staff_id INTEGER NOT NULL,
        role_in_team TEXT DEFAULT 'member' CHECK (role_in_team IN ('leader', 'member', 'specialist')),
        joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE,
        UNIQUE(team_id, staff_id)
      )
    `),a.exec(`
      CREATE TABLE IF NOT EXISTS assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_id INTEGER NOT NULL,
        team_id INTEGER,
        staff_id INTEGER,
        assigned_by INTEGER NOT NULL,
        assignment_type TEXT NOT NULL CHECK (assignment_type IN ('team', 'individual')),
        status TEXT DEFAULT 'assigned' CHECK (status IN ('assigned', 'accepted', 'in_progress', 'completed', 'cancelled')),
        assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        accepted_at DATETIME,
        started_at DATETIME,
        completed_at DATETIME,
        notes TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE SET NULL,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE SET NULL,
        FOREIGN KEY (assigned_by) REFERENCES staff(id) ON DELETE SET NULL
      )
    `),console.log("✅ SQLite database successfully initialized"),console.log("\uD83D\uDCCA Database tables created successfully")}catch(e){throw console.error("❌ Database initialization error:",e),e}})(),process.on("SIGINT",()=>{a&&(a.close(),console.log("\uD83D\uDD12 SQLite database connection closed")),process.exit(0)});let T=a}};var s=require("../../../webpack-runtime.js");s.C(e);var t=e=>s(s.s=e),a=s.X(0,[257,452],()=>t(96));module.exports=a})();