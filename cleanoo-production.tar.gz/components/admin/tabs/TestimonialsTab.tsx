'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Plus, Edit, Trash2, Star } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import Modal from '@/components/admin/shared/Modal';
import FormField from '@/components/admin/shared/FormField';

interface TestimonialsTabProps {
  testimonials: any[];
  loading: boolean;
  fetchTestimonials: () => Promise<void>;
  showTestimonialForm: boolean;
  setShowTestimonialForm: (show: boolean) => void;
}

export default function TestimonialsTab({ 
  testimonials, 
  loading, 
  fetchTestimonials, 
  showTestimonialForm, 
  setShowTestimonialForm 
}: TestimonialsTabProps) {
  const { toast } = useToast();
  const [testimonialForm, setTestimonialForm] = useState({
    name: '',
    text: '',
    rating: 5
  });
  const [editingTestimonial, setEditingTestimonial] = useState<any>(null);

  const resetForm = () => {
    setTestimonialForm({ name: '', text: '', rating: 5 });
    setEditingTestimonial(null);
  };

  const handleEdit = (testimonial: any) => {
    setEditingTestimonial(testimonial);
    setTestimonialForm({
      name: testimonial.name,
      text: testimonial.text,
      rating: testimonial.rating
    });
    setShowTestimonialForm(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!testimonialForm.name || !testimonialForm.text) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    try {
      const url = editingTestimonial ? `/api/testimonials/${editingTestimonial.id}` : '/api/testimonials';
      const method = editingTestimonial ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(testimonialForm),
      });

      if (!response.ok) throw new Error('Failed to save testimonial');

      const result = await response.json();
      if (!result.success) throw new Error(result.error || 'Failed to save testimonial');

      toast({
        title: "Success",
        description: editingTestimonial ? "Testimonial updated successfully" : "Testimonial added successfully",
      });

      setShowTestimonialForm(false);
      resetForm();
      fetchTestimonials();
    } catch (error: any) {
      console.error('Error saving testimonial:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to save testimonial.",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (testimonialId: string) => {
    if (!confirm('Are you sure you want to delete this testimonial?')) return;

    try {
      const response = await fetch(`/api/testimonials/${testimonialId}`, {
        method: 'DELETE',
      });

      if (!response.ok) throw new Error('Failed to delete testimonial');

      toast({
        title: "Success",
        description: "Testimonial deleted successfully",
      });

      fetchTestimonials();
    } catch (error: any) {
      console.error('Error deleting testimonial:', error);
      toast({
        title: "Error",
        description: "Failed to delete testimonial.",
        variant: "destructive",
      });
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ));
  };

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-2 text-gray-500">Loading testimonials...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Testimonials Management</h2>
        <Button onClick={() => setShowTestimonialForm(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Testimonial
        </Button>
      </div>

      {testimonials.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-gray-500">No testimonials found.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  {renderStars(testimonial.rating)}
                </div>
                <div className="flex space-x-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleEdit(testimonial)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDelete(testimonial.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{testimonial.name}</h3>
              <p className="text-gray-600 italic">"{testimonial.text}"</p>
            </div>
          ))}
        </div>
      )}

      {/* Testimonial Form Modal */}
      <Modal
        isOpen={showTestimonialForm}
        onClose={() => {
          setShowTestimonialForm(false);
          resetForm();
        }}
        title={editingTestimonial ? "Edit Testimonial" : "Add New Testimonial"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <FormField label="Customer Name" required>
            <input
              type="text"
              value={testimonialForm.name}
              onChange={(e) => setTestimonialForm(prev => ({ ...prev, name: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter customer name"
            />
          </FormField>

          <FormField label="Testimonial Text" required>
            <textarea
              value={testimonialForm.text}
              onChange={(e) => setTestimonialForm(prev => ({ ...prev, text: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows={4}
              placeholder="Enter testimonial text"
            />
          </FormField>

          <FormField label="Rating" required>
            <select
              value={testimonialForm.rating}
              onChange={(e) => setTestimonialForm(prev => ({ ...prev, rating: parseInt(e.target.value) }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value={1}>1 Star</option>
              <option value={2}>2 Stars</option>
              <option value={3}>3 Stars</option>
              <option value={4}>4 Stars</option>
              <option value={5}>5 Stars</option>
            </select>
          </FormField>

          <div className="flex space-x-3 pt-4">
            <Button type="submit" className="flex-1">
              {editingTestimonial ? "Update Testimonial" : "Add Testimonial"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setShowTestimonialForm(false);
                resetForm();
              }}
              className="flex-1"
            >
              Cancel
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
