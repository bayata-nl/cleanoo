'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Sparkles, Home, Building2, Car, Clock, Star, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';

import { Service, Testimonial } from '@/types';
import { useLanguage } from '@/contexts/LanguageContext';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';
import { useAuth } from '@/contexts/AuthContext';

export default function HomePage() {
  const { toast } = useToast();
  const { t } = useLanguage();
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();

  const [services, setServices] = useState<Service[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loadingServices, setLoadingServices] = useState(true);
  const [loadingTestimonials, setLoadingTestimonials] = useState(true);

  useEffect(() => {
    // Fetch services from API
    fetch('/api/services')
      .then(res => {
        if (!res.ok) {
          throw new Error('Failed to fetch services');
        }
        return res.json();
      })
      .then(data => {
        console.log('Services API response:', data); // Debug log
        if (data.success && Array.isArray(data.data)) {
          setServices(data.data);
        } else {
          console.error('Services data is not an array:', data);
          setServices([]);
        }
        setLoadingServices(false);
      })
      .catch(err => {
        console.error('Error fetching services:', err);
        setServices([]);
        setLoadingServices(false);
      });

    // Fetch testimonials from API
    fetch('/api/testimonials')
      .then(res => {
        if (!res.ok) {
          throw new Error('Failed to fetch testimonials');
        }
        return res.json();
      })
      .then(data => {
        console.log('Testimonials API response:', data); // Debug log
        if (data.success && Array.isArray(data.data)) {
          setTestimonials(data.data);
        } else {
          console.error('Testimonials data is not an array:', data);
          setTestimonials([]);
        }
        setLoadingTestimonials(false);
      })
      .catch(err => {
        console.error('Error fetching testimonials:', err);
        setTestimonials([]);
        setLoadingTestimonials(false);
      });
  }, []);



const iconMap: { [key: string]: React.ComponentType<{ className?: string }> } = {
  Home,
  Building2,
  Car,
  Clock,
  Sparkles
};


  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
            {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center justify-center px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800">
        <div className="absolute inset-0 bg-black/20"></div>
        
        {/* Language Switcher and Auth Links */}
        <div className="absolute top-6 right-6 z-30 flex items-center space-x-4">
          <LanguageSwitcher />
          {authLoading ? (
            <div className="animate-pulse bg-white/10 rounded px-3 py-2">
              <div className="w-16 h-4 bg-white/20 rounded"></div>
            </div>
          ) : user ? (
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/10"
              onClick={() => router.push('/dashboard')}
            >
              <User className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
          ) : (
            <div className="flex space-x-3">
              <Button
                variant="outline"
                size="sm"
                className="bg-white/10 text-white border-white/30 hover:bg-white/20 hover:border-white/50 px-4 py-2 font-medium backdrop-blur-sm"
                onClick={() => router.push('/login')}
              >
                Login
              </Button>
              <Button
                variant="default"
                size="sm"
                className="bg-white text-blue-700 hover:bg-blue-50 border-0 px-4 py-2 font-medium shadow-lg"
                onClick={() => router.push('/register')}
              >
                Sign Up
              </Button>
            </div>
          )}
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto text-center text-white">
          <div className="flex justify-center mb-8">
            <div className="p-4 bg-white/10 backdrop-blur-sm rounded-full">
              <Sparkles className="h-16 w-16 text-white" />
            </div>
          </div>
          <h1 className="text-5xl sm:text-7xl font-bold mb-6">
            {t('hero.title')}
            <span className="block text-blue-200">{t('hero.subtitle')}</span>
          </h1>
          <p className="text-xl sm:text-2xl text-blue-100 mb-10 max-w-3xl mx-auto leading-relaxed">
            {t('hero.description')}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="text-lg px-8 py-4 bg-white text-blue-700 hover:bg-blue-50 font-semibold"
              onClick={() => document.getElementById('booking-form')?.scrollIntoView({ behavior: 'smooth' })}
            >
              {t('hero.bookButton')}
            </Button>
            <Button 
              size="lg" 
              className="text-lg px-8 py-4 bg-blue-500 text-white hover:bg-blue-600 font-semibold border-2 border-blue-500 hover:border-blue-600"
              onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}
            >
              {t('hero.viewServicesButton')}
            </Button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
              {t('services.title')}
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              {t('services.description')}
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {loadingServices ? (
              // Loading skeleton
              Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100 animate-pulse">
                  <div className="w-20 h-20 bg-gray-200 rounded-2xl mb-6 mx-auto"></div>
                  <div className="h-6 bg-gray-200 rounded mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-6 bg-gray-200 rounded w-24 mx-auto"></div>
                </div>
              ))
            ) : Array.isArray(services) && services.length > 0 ? (
              services.map((service) => {
                const IconComponent = iconMap[service.icon];
                return (
                  <div key={service.id} className="group bg-white rounded-2xl shadow-lg p-8 border border-gray-100 hover:shadow-2xl hover:scale-105 transition-all duration-300 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-indigo-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <div className="relative z-10">
                      <div className="flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl mb-6 mx-auto group-hover:scale-110 transition-transform duration-300">
                        {IconComponent && <IconComponent className="h-10 w-10 text-white" />}
                      </div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-4 text-center">
                        {service.title}
                      </h3>
                      <p className="text-gray-600 mb-6 text-center leading-relaxed">
                        {service.description}
                      </p>
                      {service.price && (
                        <div className="text-center">
                          <p className="text-2xl font-bold text-blue-600">
                            {service.price}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="col-span-3 text-center py-8">
                <p className="text-gray-500">No services available</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
              {t('testimonials.title')}
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              {t('testimonials.description')}
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {loadingTestimonials ? (
              // Loading skeleton
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100 animate-pulse">
                  <div className="h-1 bg-gray-200 rounded-t-2xl mb-6"></div>
                  <div className="flex mb-6">
                    {[...Array(5)].map((_, j) => (
                      <div key={j} className="w-6 h-6 bg-gray-200 rounded mr-1"></div>
                    ))}
                  </div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded mb-6"></div>
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gray-200 rounded-full mr-4"></div>
                    <div className="h-4 bg-gray-200 rounded w-24"></div>
                  </div>
                </div>
              ))
            ) : Array.isArray(testimonials) && testimonials.length > 0 ? (
              testimonials.map((testimonial) => (
                <div key={testimonial.id} className="group bg-white rounded-2xl shadow-lg p-8 border border-gray-100 hover:shadow-2xl hover:scale-105 transition-all duration-300 relative">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-t-2xl"></div>
                  <div className="flex mb-6">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-6 w-6 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-6 italic text-lg leading-relaxed">
                    "{testimonial.text}"
                  </p>
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mr-4">
                      <span className="text-white font-bold text-lg">
                        {testimonial.name.charAt(0)}
                      </span>
                    </div>
                    <p className="text-white font-bold text-lg">
                      {testimonial.name}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-3 text-center py-8">
                <p className="text-gray-500">No testimonials available</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Login to Book Section */}
      <section id="booking-form" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
              Ready to Book Your Cleaning?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Login to your account to book cleaning services and manage your bookings
            </p>
          </div>
          
          <div className="bg-white rounded-2xl shadow-2xl p-8 border border-gray-100 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-indigo-600"></div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <User className="h-10 w-10 text-white" />
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                {user ? 'Welcome back!' : 'Login to Book Services'}
              </h3>
              
              <p className="text-gray-600 mb-8 max-w-md mx-auto">
                {user 
                  ? 'You are already logged in. Go to your dashboard to book services.'
                  : 'Please login to your account to book cleaning services and manage your bookings.'
                }
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                {user ? (
                  <Button
                    onClick={() => router.push('/dashboard')}
                    className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold py-4 px-8 rounded-xl transition-all duration-300 transform hover:scale-105"
                  >
                    <User className="h-5 w-5 mr-3" />
                    Go to Dashboard
                  </Button>
                ) : (
                  <>
                    <Button
                      onClick={() => router.push('/login')}
                      className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold py-4 px-8 rounded-xl transition-all duration-300 transform hover:scale-105"
                    >
                      <User className="h-5 w-5 mr-3" />
                      Login
                    </Button>
                    <Button
                      onClick={() => router.push('/register')}
                      variant="outline"
                      className="border-2 border-blue-600 text-blue-600 hover:bg-blue-50 font-semibold py-4 px-8 rounded-xl transition-all duration-300"
                    >
                      Create Account
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex justify-center mb-8">
            <div className="p-4 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full">
              <Sparkles className="h-12 w-12 text-white" />
            </div>
          </div>
          <h3 className="text-3xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">
            Cleanoo
          </h3>
                     <p className="text-gray-300 mb-8 text-lg max-w-2xl mx-auto">
             {t('footer.description')}
           </p>
           <div className="flex justify-center space-x-8 text-sm text-gray-400">
             <span>{t('footer.copyright')}</span>
           </div>
        </div>
      </footer>
    </div>
  );
} 