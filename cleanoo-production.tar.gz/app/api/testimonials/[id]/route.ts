import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/sqlite';

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const testimonial = db.prepare('SELECT * FROM testimonials WHERE id = ?').get(id);
    
    if (!testimonial) {
      return NextResponse.json({ error: 'Testimonial not found' }, { status: 404 });
    }
    
    return NextResponse.json(testimonial);
  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { name, text, rating } = body;

    // Validation
    if (!name || !text || !rating) {
      return NextResponse.json({ error: 'Name, text and rating are required' }, { status: 400 });
    }

    if (rating < 1 || rating > 5) {
      return NextResponse.json({ error: 'Rating must be between 1 and 5' }, { status: 400 });
    }

    const stmt = db.prepare(`
      UPDATE testimonials 
      SET name = ?, text = ?, rating = ?, created_at = created_at
      WHERE id = ?
    `);
    
    const result = stmt.run(name, text, rating, id);
    
    if (result.changes === 0) {
      return NextResponse.json({ error: 'Testimonial not found' }, { status: 404 });
    }
    
    // Get updated record
    const updated = db.prepare('SELECT * FROM testimonials WHERE id = ?').get((await params).id);
    
    return NextResponse.json({ 
      success: true, 
      data: updated,
      message: 'Testimonial successfully updated'
    });
  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Internal server error' 
    }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const stmt = db.prepare('DELETE FROM testimonials WHERE id = ?');
    const result = stmt.run(id);
    
    if (result.changes === 0) {
      return NextResponse.json({ error: 'Testimonial not found' }, { status: 404 });
    }
    
    return NextResponse.json({ 
      success: true, 
      message: 'Testimonial successfully deleted'
    });
  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Internal server error' 
    }, { status: 500 });
  }
}