import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/sqlite';

export async function GET() {
  try {
    const testimonials = db.prepare('SELECT * FROM testimonials ORDER BY created_at DESC').all();
    return NextResponse.json({ 
      success: true, 
      data: testimonials 
    });
  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Internal server error' 
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, text, rating } = body;

    // Validation
    if (!name || !text || !rating) {
      return NextResponse.json({ error: 'Name, text and rating are required' }, { status: 400 });
    }

    if (rating < 1 || rating > 5) {
      return NextResponse.json({ error: 'Rating must be between 1 and 5' }, { status: 400 });
    }

    const stmt = db.prepare(`
      INSERT INTO testimonials (name, text, rating) 
      VALUES (?, ?, ?)
    `);
    
    const result = stmt.run(name, text, rating);
    
    // Get inserted record
    const inserted = db.prepare('SELECT * FROM testimonials WHERE id = ?').get(result.lastInsertRowid);
    
    return NextResponse.json({ 
      success: true, 
      data: inserted,
      message: 'Testimonial successfully created'
    }, { status: 201 });
  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Internal server error' 
    }, { status: 500 });
  }
}