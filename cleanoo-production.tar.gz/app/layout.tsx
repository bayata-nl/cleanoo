import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Toaster } from '@/components/ui/toaster'
import { LanguageProvider } from '@/contexts/LanguageContext'
import { AuthProvider } from '@/contexts/AuthContext'
import { StaffAuthProvider } from '@/contexts/StaffAuthContext'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Cleanoo - Professional Cleaning Services',
  description: 'Professional cleaning services for homes and offices. Book your cleaning service today!',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <AuthProvider>
          <StaffAuthProvider>
            <LanguageProvider>
              {children}
              <Toaster />
            </LanguageProvider>
          </StaffAuthProvider>
        </AuthProvider>
      </body>
    </html>
  )
} 